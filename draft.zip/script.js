console.log('works')
const slides = 4
const slide = `<div class="slide" >
<div class="card-frame">
  <div class="card-img">
    <img class="resize_fit_center" src="http://example.canarycasas.com/de/orange.png" />
  </div>
  <!---Product card color background , title and description , link to product ---->
  <div class="card-main">
    <a href="#">
      <div class="card-color">
        <div class="card-title">
          <h3>Super Juice Orange</h3>
          <p>Zumo de naranja puro exprimido</p>
        </div>
      </div>
    </a>
    <!---Product card infos und price---->
    <div class="card-content">
      <div class="content-left">
        <p class="c-left-1">12 x 0,7 L (PET)</p>
        <p class="c-left-2">
          desechable
          <a href="#">
            <span class="HAstopwatch yqb-green"></span>
          </a>
        </p>
      </div>
      <div class="content-right">
        <div class="c-right-1">
          <p>
            <strong><span>10,08</span></strong> €
          </p>
        </div>
      </div>
    </div>
    <!---Card increment button set---->
    <div class="card-shop">
      <div class="shop-set">
        <div class="increment">
          <div class="input-group">
            <input type="button" value="-" class="button-minus" data-field="quantity" />
            <input
              type="number"
              step="1"
              max=""
              value="1"
              name="quantity"
              class="quantity-field"
            />
            <input
              type="button"
              value="+"
              class="button-plus yqb-green-bg"
              data-field="quantity"
            />
          </div>
        </div>
        <div class="shop-button" type="button">
          <span class="HAstopwatch yqb-red"></span>
        </div>
        <div class="herz-button" type="button" data-field="">
          <span class="HAstopwatch greytxt"></span>
        </div>
      </div>
    </div>
  </div>
  <!---Card more below , Text info to more products of that kind, link to product list---->
  <div class="card-more">
    <div class="more-left">
      <h4 class="yqb-green fsize16">Super Juice Orange</h4>
      <p class="greytxt fsize12">Descubra todos los articulos</p>
    </div>
    <a href="#">
      <div class="more-right">
        <p>
          <span class="HAstopwatch yqb-green"></span>
        </p>
      </div>
    </a>
  </div>
</div>
</div>`

let carousel = $('#carousel'),
  threshold = 150,
  slideWidth = 425,
  dragStart,
  dragEnd
for (let i = 0; i < (slides <= 4 ? slides * 2 : slides); i++) {
  carousel.append(slide)
}
if (slides % 2 === 0) {
  carousel.css({ left: `-${slideWidth / 2}` })
}
$('#next').click(function () {
  shiftSlide(-1)
})
$('#prev').click(function () {
  shiftSlide(1)
})

carousel.on('mousedown', function () {
  if (carousel.hasClass('transition')) return
  dragStart = event.pageX
  $(this).on('mousemove', function () {
    dragEnd = event.pageX
    $(this).css('transform', 'translateX(' + dragPos() + 'px)')
  })
  $(document).on('mouseup', function () {
    if (dragPos() > threshold) {
      return shiftSlide(1)
    }
    if (dragPos() < -threshold) {
      return shiftSlide(-1)
    }
    shiftSlide(0)
  })
})

function dragPos() {
  return dragEnd - dragStart
}

function shiftSlide(direction) {
  if (carousel.hasClass('transition')) return
  dragEnd = dragStart
  $(document).off('mouseup')
  carousel
    .off('mousemove')
    .addClass('transition')
    .css('transform', 'translateX(' + direction * slideWidth + 'px)')
  setTimeout(function () {
    if (direction === 1) {
      $('.slide:first').before($('.slide:last'))
    } else if (direction === -1) {
      $('.slide:last').after($('.slide:first'))
    }
    carousel.removeClass('transition')
    carousel.css('transform', 'translateX(0px)')
  }, 700)
}
